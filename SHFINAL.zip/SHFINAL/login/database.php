<?php



$connection = mysqli_connect(
  'localhost', 'id18610335_kronox724', 'ZHzSz4z)+Ea*PnLr', 'id18610335_kronox'
);

// for testing connection
#if($connection) {
#  echo 'database is connected';
#}

?>
<?php 
$con = mysqli_connect('localhost', 'id18610335_kronox724','ZHzSz4z)+Ea*PnLr','id18610335_kronox');
 ?>